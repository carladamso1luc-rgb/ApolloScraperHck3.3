const Apify = require('apify');
const { extractContactData, randomDelay } = require('./helpers');

Apify.main(async () => {
    const input = await Apify.getInput();
    const { apolloUrls, apolloCookie, maxContacts, proxyConfig } = input;
    const requestQueue = await Apify.openRequestQueue();

    for (const url of apolloUrls) await requestQueue.addRequest({ url });

    let scrapedCount = 0;
    const dataset = await Apify.openDataset();

    const crawler = new Apify.PlaywrightCrawler({
        requestQueue,
        maxRequestRetries: 5,
        maxConcurrency: 3,
        proxyConfiguration: await Apify.createProxyConfiguration(proxyConfig),
        launchContext: {
            launchOptions: {
                headless: true,
            },
        },
        preNavigationHooks: [
            async ({ page }, gotoOptions) => {
                if (apolloCookie) {
                    // Support both raw "key1=val1; key2=val2" and JSON list of cookies
                    let cookies;
                    try {
                        cookies = JSON.parse(apolloCookie);
                        // JSON array of cookies
                    } catch {
                        // Parse raw cookie string
                        cookies = apolloCookie.split(";").map(c => {
                            const [name, ...v] = c.trim().split("=");
                            return {
                                name,
                                value: v.join("="),
                                domain: ".apollo.io",
                                path: "/",
                                httpOnly: false,
                                secure: true
                            };
                        });
                    }
                    await page.context().addCookies(cookies);
                }
            }
        ],
        handlePageFunction: async ({ request, page, log }) => {
            await randomDelay();
            log.info(`Scraping: ${request.url}`);
            const contact = await extractContactData(page);
            if (contact && (contact.email || contact.name)) {
                contact.sourceUrl = request.url;
                await dataset.pushData(contact);
                scrapedCount++;
            }
            if (scrapedCount >= maxContacts) {
                log.info(`Reached max contacts: ${maxContacts}`);
                await crawler.teardown();
            }
        },
        handleFailedRequestFunction: async ({ request, error, log }) => {
            log.error(`Request ${request.url} failed: ${error}`);
        },
        navigationTimeoutSecs: 60,
    });

    await crawler.run();
});