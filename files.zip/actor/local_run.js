const Apify = require('apify');
const fs = require('fs');
process.env.APIFY_LOCAL_STORAGE_DIR = './apify_storage';
const input = JSON.parse(fs.readFileSync('input.json', 'utf-8'));
Apify.main(async () => require('./main.js'));