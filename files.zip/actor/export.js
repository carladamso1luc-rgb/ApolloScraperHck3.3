const fs = require('fs');
const AdmZip = require('adm-zip');

(async () => {
    const dataPath = './apify_storage/datasets/default';
    const outputCsv = 'results.csv';
    const outputTxt = 'results.txt';
    const outputZip = 'results.zip';
    const raw = JSON.parse(fs.readFileSync(`${dataPath}/000000001.json`, 'utf8'));
    const items = raw.items || raw;

    // CSV
    const keys = Object.keys(items[0] || {});
    const csv = [
        keys.join(','),
        ...items.map(row => keys.map(k => JSON.stringify(row[k] || '')).join(','))
    ].join('\n');
    fs.writeFileSync(outputCsv, csv);

    // TXT
    const txt = items.map(c => keys.map(k => c[k]).join(' | ')).join('\n');
    fs.writeFileSync(outputTxt, txt);

    // ZIP
    const zip = new AdmZip();
    zip.addLocalFile(outputCsv);
    zip.addLocalFile(outputTxt);
    zip.writeZip(outputZip);
})();