const randomDelay = async () => {
    // Sleep 2-4s random delay to avoid detection
    await new Promise(res => setTimeout(res, 2000 + Math.random() * 2000));
};

const extractContactData = async (page) => {
    // Wait for main contact name or email (modify selectors as needed)
    try {
        await page.waitForSelector('[data-testid*="contact"]', { timeout: 15000 });
    } catch {
        await page.waitForTimeout(5000);
    }

    // Try multiple selectors for robustness
    return await page.evaluate(() => {
        // Try to get data by data-testid or fallback to visible text
        function getText(sel) {
            return document.querySelector(sel)?.textContent?.trim() || '';
        }
        // Adjust these based on Apollo.io's DOM
        const name = getText('[data-testid="contact-name"]') ||
            getText('[data-testid="contact-details-name"]') ||
            getText('.sc-dkPtRN.cXvMox'); // fallback class

        const email = getText('[data-testid="contact-email"]') ||
            getText('.sc-jrsJWt.hUjBoG');

        const jobTitle = getText('[data-testid="contact-title"]') ||
            getText('.job-title');

        const company = getText('[data-testid="contact-company"]') ||
            getText('.company-name');

        const phone = getText('[data-testid="contact-phone"]') ||
            getText('.phone-number');

        const location = getText('[data-testid="contact-location"]') ||
            getText('.location');

        return { name, email, jobTitle, company, phone, location };
    });
};

module.exports = { extractContactData, randomDelay };