# Apollo.io Contact Scraper (Apify Actor + Dashboard)

The most user-friendly, production-ready Apollo.io contact scraper for cybersecurity research!

---

## Features

- Scrapes email, name, job title, company, phone, and location from Apollo.io using a real browser (Playwright).
- **User-friendly dashboard:** Just open `dashboard-build/index.html`.
- **Works on Apify cloud or locally (Windows, Docker).**
- Exports results as CSV, TXT, and ZIP.
- Handles retries, proxies, captchas, rate-limits.
- No coding required for setup or use.

---

## Quick Start (for Non-Coders)

### 1. **Download & Unzip**

- Download the ZIP file or clone the repo.
- Unzip to a folder (e.g., `C:\ApolloScraper`).

### 2. **Run on Windows**

- Double-click `run.ps1` (requires [Docker Desktop](https://www.docker.com/products/docker-desktop/)).
- Double-click `dashboard-build/index.html` for the UI.

### 3. **Run on Apify**

- Push actor with `apify push`.
- Use Apify dashboard or API.

---

## Dashboard Usage

1. Enter Apollo.io URL(s), your login cookie, and max contacts.
2. Click **Start**. Watch real-time log and progress bar.
3. Download CSV, TXT, or ZIP when done.

---

## For Developers

- Monorepo: `/actor` (scraper), `/dashboard` (UI), `/server` (proxy/websocket).
- Run `npm install` in each subfolder.
- See input schema in `INPUT_SCHEMA.json`.

---

## Legal & Ethical Notice
Use only for **authorized, supervised cybersecurity research**. Do not violate Apollo.io's terms of service or applicable laws.

---

## Troubleshooting

- If stuck, restart Docker and try again.
- Log issues or PRs on GitHub!

---

## Credits

By carladamso1luc-rgb. UI theme based on shadcn/ui & Tailwind.