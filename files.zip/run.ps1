Write-Host "Building Docker image for Apollo-Scraper..."
docker build -t apollo-scraper .
Write-Host "Running container and starting server..."
docker run --rm -d -p 3001:3001 -v ${PWD}:/app apollo-scraper
Start-Process "dashboard-build/index.html"
Write-Host "Apollo-Scraper is running!"