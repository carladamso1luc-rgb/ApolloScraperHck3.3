import React, { useState, useRef } from "react";

const API_URL = "http://localhost:3001";

export default function App() {
  const [apolloUrls, setApolloUrls] = useState("");
  const [apolloCookie, setApolloCookie] = useState("");
  const [maxContacts, setMaxContacts] = useState(100);
  const [fileName, setFileName] = useState("results");
  const [progress, setProgress] = useState(0);
  const [log, setLog] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  const startScrape = async () => {
    setIsRunning(true);
    setLog("");
    setProgress(0);

    const resp = await fetch(`${API_URL}/get-token`, { method: "POST" });
    const { token } = await resp.json();

    wsRef.current = new window.WebSocket(`ws://localhost:3001/ws`);
    wsRef.current.onmessage = (evt) => {
      const msg = JSON.parse(evt.data);
      if (msg.type === "progress") setProgress(msg.value);
      if (msg.type === "log") setLog((l) => l + msg.text + "\n");
    };
    wsRef.current.onclose = () => setIsRunning(false);

    await fetch(`${API_URL}/start-job`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        apolloUrls: apolloUrls.split("\n").filter(Boolean),
        apolloCookie,
        maxContacts,
        fileName,
      }),
    });
  };

  const stopScrape = () => {
    wsRef.current?.close();
    setIsRunning(false);
  };

  const download = (type: string) => {
    window.open(`${API_URL}/download?type=${type}&fileName=${fileName}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-black text-hacker font-mono p-6">
      <h1 className="text-3xl mb-4 font-bold">Apollo.io Contact Scraper 🛡️</h1>
      <form
        className="mb-4"
        onSubmit={(e) => {
          e.preventDefault();
          startScrape();
        }}
      >
        <div className="mb-2">
          <label className="block">Apollo.io URLs (one per line):</label>
          <textarea
            className="w-full p-2 bg-gray-900 text-hacker"
            value={apolloUrls}
            onChange={e => setApolloUrls(e.target.value)}
            rows={3}
            required
          />
        </div>
        <div className="mb-2">
          <label className="block">Apollo.io Cookie:</label>
          <input
            type="text"
            className="w-full p-2 bg-gray-900 text-hacker"
            value={apolloCookie}
            onChange={e => setApolloCookie(e.target.value)}
            required
          />
        </div>
        <div className="mb-2 flex space-x-4">
          <div>
            <label>Max Contacts:</label>
            <input
              type="number"
              min={100}
              max={2500}
              value={maxContacts}
              required
              className="w-24 ml-2 p-2 bg-gray-900 text-hacker"
              onChange={e => setMaxContacts(Number(e.target.value))}
            />
          </div>
          <div>
            <label>File Name:</label>
            <input
              type="text"
              value={fileName}
              required
              className="w-32 ml-2 p-2 bg-gray-900 text-hacker"
              onChange={e => setFileName(e.target.value)}
            />
          </div>
        </div>
        <div className="mt-4 flex space-x-2">
          <button
            type="submit"
            className="px-4 py-2 bg-hacker text-black font-bold rounded"
            disabled={isRunning}
          >Start</button>
          <button
            type="button"
            className="px-4 py-2 bg-red-600 text-white font-bold rounded"
            onClick={stopScrape}
            disabled={!isRunning}
          >Stop</button>
        </div>
      </form>
      <div className="mb-2">
        <div className="w-full bg-gray-800 h-4 rounded overflow-hidden">
          <div
            className="bg-hacker h-4"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <span className="text-sm">{progress}% done</span>
      </div>
      <div className="mb-2">
        <label className="block">Log:</label>
        <textarea
          className="w-full h-48 p-2 bg-gray-900 text-green-400"
          value={log}
          readOnly
          aria-live="polite"
        />
      </div>
      <div className="flex space-x-2">
        <button
          className="px-4 py-2 bg-hacker text-black font-bold rounded"
          onClick={() => download("csv")}
        >Download CSV</button>
        <button
          className="px-4 py-2 bg-hacker text-black font-bold rounded"
          onClick={() => download("txt")}
        >Download TXT</button>
        <button
          className="px-4 py-2 bg-hacker text-black font-bold rounded"
          onClick={() => download("zip")}
        >Download ZIP</button>
      </div>
    </div>
  );
}