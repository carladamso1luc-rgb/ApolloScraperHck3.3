exports.getToken = () => {
    return process.env.APIFY_TOKEN || 'demo-token';
};