const express = require('express');
const cors = require('cors');
const { getToken } = require('./token');
const { setupWebSocket, notifyProgress } = require('./ws');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const app = express();
app.use(cors());
app.use(express.json());

let wsClients = [];

app.post('/get-token', (req, res) => {
    const token = getToken();
    res.json({ token });
});

app.post('/start-job', (req, res) => {
    const { apolloUrls, apolloCookie, maxContacts, fileName } = req.body;
    const input = {
        apolloUrls,
        apolloCookie,
        maxContacts,
        proxyConfig: null
    };
    fs.writeFileSync('actor/input.json', JSON.stringify(input, null, 2));
    const ps = spawn('node', ['local_run.js'], { cwd: 'actor' });
    ps.stdout.on('data', data => {
        notifyProgress(wsClients, { type: "log", text: data.toString() });
    });
    ps.stderr.on('data', data => {
        notifyProgress(wsClients, { type: "log", text: data.toString() });
    });
    ps.on('close', (code) => {
        notifyProgress(wsClients, { type: "progress", value: 100 });
        notifyProgress(wsClients, { type: "log", text: "Job complete!" });
        // Post-process: create CSV/TXT/ZIP for download
        spawn('node', ['export.js'], { cwd: 'actor' });
    });
    notifyProgress(wsClients, { type: "progress", value: 10 });
    res.json({ status: "started" });
});

app.get('/download', (req, res) => {
    const { type, fileName } = req.query;
    let filePath = "";
    if (type === "csv") filePath = path.join(__dirname, "../actor/results.csv");
    if (type === "txt") filePath = path.join(__dirname, "../actor/results.txt");
    if (type === "zip") filePath = path.join(__dirname, "../actor/results.zip");
    if (!fs.existsSync(filePath)) return res.status(404).send("File not found");
    res.download(filePath, `${fileName || 'results'}.${type}`);
});

const server = app.listen(3001, () => console.log("Server running on 3001"));
setupWebSocket(server, wsClients);