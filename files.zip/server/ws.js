const WebSocket = require('ws');

function setupWebSocket(server, wsClients) {
    const wss = new WebSocket.Server({ server, path: '/ws' });
    wss.on('connection', (ws) => {
        wsClients.push(ws);
        ws.on('close', () => {
            const idx = wsClients.indexOf(ws);
            if (idx !== -1) wsClients.splice(idx, 1);
        });
    });
}
function notifyProgress(wsClients, message) {
    wsClients.forEach(ws => {
        if (ws.readyState === 1) ws.send(JSON.stringify(message));
    });
}
module.exports = { setupWebSocket, notifyProgress };